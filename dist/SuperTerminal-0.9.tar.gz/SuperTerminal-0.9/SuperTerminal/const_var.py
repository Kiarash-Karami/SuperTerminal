from enum import Enum

class Color(Enum):
    GRAY = "\033[38;5;8m"
    RESET = "\033[0m"
